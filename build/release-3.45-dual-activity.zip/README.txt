FlashFloppy 3.45-dual: complete build with runtime Settings, QD READY and R/W activity.

STM32F105 USB files:
  Firmware: alt/dual/FF_Gotek-dual-3.45-dual.upd
  Bootloader updater: alt/bootloader/FF_Gotek-bootloader-3.45-dual.upd
Modern update catalogs in the same folders support STM32F105 and AT32F435.
For each update, put only its chosen .upd on the USB drive.

To install both, update the bootloader first, then install the dual firmware.
The bootloader updater erases its own application after success. Replace the
USB update file with the dual firmware and restart; the bootloader will load it.

Logical legacy .qd, .mzq and all .qdf images are read-only. They cannot be
formatted or written, even with write-protect=no. The display shows * as soon
as the image is mounted. Native physical .qd retains its working write path.
QD READY: qd-ready = standard | motor-off | jc; independent of FDD interface.
Sharp preset: interface=shugart, qd-ready=motor-off.
SELECT -> Eject Menu -> Settings changes are RAM-only until reset.
QD percentages are removed. R indicates the READY read stream; W only
during accepted physical WGATE, never USB writeback alone. OLED/LCD shows
* for every read-only image, also alongside R. Seven-segment: rd/wrt/qd.
See universal-settings-validation.md for build sizes and hardware checklist.

variants/ contains every supported production, debug and logfile build,
including bootloaders and the special STM32F105 Apple2 bootloader.
Combined debug/logfile dual builds are available for AT32F435 only, following
the existing STM32F105 flash-size limitation.

All image read/protection tests, MCU dispatcher tests, flash checks, linked
engine/HEX checks, bootloader payload checks and update CRC verification passed.
